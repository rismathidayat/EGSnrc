var searchData=
[
  ['calculate_5fg_13',['calculate_g',['../g_8f.html#a51eb78b9f2a929857af000d30756b51f',1,'g.f']]]
];
