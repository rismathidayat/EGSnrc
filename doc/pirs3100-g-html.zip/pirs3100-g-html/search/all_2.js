var searchData=
[
  ['g_2edoxy_2',['g.doxy',['../g_8doxy.html',1,'']]],
  ['g_2ef_3',['g.f',['../g_8f.html',1,'']]]
];
