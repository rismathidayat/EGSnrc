var indexSectionsWithContent =
{
  0: "acghinst",
  1: "g",
  2: "achist",
  3: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

