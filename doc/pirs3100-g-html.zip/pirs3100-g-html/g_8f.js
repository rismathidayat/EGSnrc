var g_8f =
[
    [ "ausgab", "g_8f.html#acc64c5edb16539e7afc7beed4e0ce958", null ],
    [ "calculate_g", "g_8f.html#a51eb78b9f2a929857af000d30756b51f", null ],
    [ "howfar", "g_8f.html#a5c1d36f2726c01d35d48589d77bac767", null ],
    [ "inputs", "g_8f.html#ab10ee8cefc314b55c20ba554b8e0360c", null ],
    [ "source", "g_8f.html#af6b2bf76a0a0eb2c3f36941d8886f269", null ],
    [ "test_brems", "g_8f.html#aa4db56a6f5440d9f739a4602561e7cb6", null ],
    [ "test_compton", "g_8f.html#a7e0fca5272477a98e4f007eaff7003bd", null ]
];